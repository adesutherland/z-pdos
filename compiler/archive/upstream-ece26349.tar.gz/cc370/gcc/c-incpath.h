/* Set up combined include path for the preprocessor.
   Copyright (C) 2003 Free Software Foundation, Inc.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

extern void split_quote_chain (void);
extern void add_path (char *, int, int);
extern void register_include_chains (cpp_reader *, const char *,
				     const char *, int, int, int);

enum { QUOTE = 0, BRACKET, SYSTEM, AFTER };
